#! /bin/bash
# mogenius.sh

echo "Starting PbxBot on Mogenius"
python3 webapp.py
