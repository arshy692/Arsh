DEVLIST = [
    "6566179661",   # bad munda
    "6898413162", # bad munda 2
    "6415940074", # dvil 
]

HARMFUL = [
    "base64",
    "bash",
    "get_me()",
    "phone",
    "os.system",
    "sys.stdout",
    "sys.stderr",
    "subprocess",
    "session.save()",
    "PBXBOT_SESSION",
    "INSTAGRAM_SESSION",
    "DATABASE_URL",
    "BOT_TOKEN",
    "API_HASH",
    "APP_ID",
    "HEROKU_API_KEY",
]

INVALID_UPLOAD = ["PB-XBot.session-journal", "PB-XBot.session", "insta/settings.json"]
