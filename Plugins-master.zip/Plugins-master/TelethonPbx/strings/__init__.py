from TelethonPbx.strings.devs import *
from TelethonPbx.strings.fun_str import *
from TelethonPbx.strings.meme_str import *
from TelethonPbx.strings.others import *
from TelethonPbx.strings.quotes import *
from TelethonPbx.strings.rands import *
