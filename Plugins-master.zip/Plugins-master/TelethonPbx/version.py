from telethon import version as ver

__telever__ = ver.__version__

__Pbxver__ = "α • 1.4.5"
#__Pbxver__ = "β • 1.5.0"
