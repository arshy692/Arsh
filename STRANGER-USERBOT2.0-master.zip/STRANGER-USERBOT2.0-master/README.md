<p align="center">⚡️𝗦𝗧𝗥𝗔𝗡𝗚𝗘𝗥-𝗨𝗦𝗘𝗥𝗕𝗢𝗧⚡️</p>

<img src="https://graph.org/file/c6a2ed96648fd03377dc9.jpg">

<p align="center">⚡️𝗔 𝗣𝗢𝗪𝗘𝗥𝗙𝗨𝗟 𝗜𝗗 𝗨𝗦𝗘𝗥𝗕𝗢𝗧⚡️</p>

<p align="center">
    <a href="https://www.python.org/" alt="made-with-python"> <img src="https://img.shields.io/badge/Made%20with-Python-black.svg?style=flat-square&logo=python&logoColor=blue&color=red" /></a>

## Requirements 

- PyroGram Session
- Dummy account
- Python 3.8+ or 3.7
- [Mongo Db](https://youtu.be/mnvjt_a5JYA)

## String Session

<p align="center"><a href="https://replit.com/@Itz-zaid/pyrogram"> <img src="https://img.shields.io/badge/String%20Session-black?style=for-the-badge&logo=replit" width="220" height="38.45"/></a></p>


## 𝐃𝐄𝐏𝐋𝐎𝐘𝐌𝐄𝐍𝐓𝐒

ᴛᴏ ʙᴇ ꜱᴀꜰᴇ ꜰᴏʀᴋ ᴛʜɪꜱ ʀᴇᴘᴏ ᴀɴᴅ ᴛʜᴇɴ ᴘʀᴇꜱꜱ ᴅᴇᴘʟᴏʏ ʙᴜᴛᴛᴏɴ ꜰʀᴏᴍ ᴛʜᴇ ꜰᴏʀᴋᴇᴅ ʀᴇᴘᴏ 

[ꜰᴏʀᴋ ᴅᴇᴘʟᴏʏ ɪꜱ ʜɪɢʜʟʏ ʀᴇᴄᴏᴍᴍᴇɴᴅᴇᴅ](https://telegra.ph/file/5bcf79f948ca06030640c.mp4)

<p align="center"><a href="http://dashboard.heroku.com/new?template=https://github.com/itzshukla/STRANGER-USERBOT2.0"> <img src="https://img.shields.io/badge/Deploy%20On%20Heroku-pink?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

## Features 

- **Spamming!**
- **You Can deploy Upto 10 Clients At a Same Time**
- **Almost 90+ Plugins There adding more Plugins Soon**
- **Id Safety Specially For Fake accounts**


## Deploy To Render 

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/STRANGER-USERBOT2.0)


```

## Disclaimer 


```console
      ⚠️ WARNING FOR YOU ⚠️
       Your Telegram account may get banned.
   I am not responsible for any improper use of this bot
This bot is intended for the purpose of having fun with memes,
      as well as efficiently managing groups.
You ended up spamming groups, getting reported left and right,
and you ended up in a Finale Battle with Telegram and at the end
       Telegram Team deleted your account?
  And after that, then you pointed your fingers at us
        for getting your acoount deleted?
    I will be rolling on the floor laughing at you.
```

## Credits 💖
- [𝗦𝗛𝗜𝗩𝗔𝗡𝗦𝗛](https://t.me/SHIVANSH39)
- [𝗦𝗧𝗥𝗔𝗡𝗚𝗘𝗥](https://t.me/SHIVANSH474) 

## Support / Channel

<p align="center">𝐒𝐮𝐩𝐩𝐨𝐫𝐭 / 𝐂𝐡𝐚𝐧𝐧𝐞𝐥 ----> </p>

<p align="center"><a href="https://t.me/MASTIWITHFRIENDSXD"><img src="https://img.shields.io/badge/ᴛᴇʟᴇɢʀᴀᴍ-𝐒𝐮𝐩𝐩𝐨𝐫𝐭-black?&style=for-the-badge&logo=telegram" width="220" height="38.45"></a></p>
<p align="center"><a href="https://t.me/SHIVANSH474"><img src="https://img.shields.io/badge/ᴛᴇʟᴇɢʀᴀᴍ-𝐔𝐩𝐝𝐚𝐭𝐞𝐬-black?&style=for-the-badge&logo=telegram" width="220" height="38.45"></a></p>
